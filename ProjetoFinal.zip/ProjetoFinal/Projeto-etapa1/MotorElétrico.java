import java.time.LocalDate;
import java.time.temporal.ChronoUnit;


public class MotorElétrico extends Equipamento {
    private double temperaturaAtual;
    private double temperaturaIdeal = 70.0;
    private double aumentoMes = 4.0;
    private double reduçãoVidaUtil = 2.0;
    
    
    public MotorElétrico(String nome, LocalDate dataInstalação) {
        super(nome, dataInstalação);
        this.tipo = "Motor Elétrico";
        this.vidaUtil = 5;
        this.frequenciaManutenções = 6;
        this.temperaturaAtual = temperaturaIdeal;
    }
    
    
    
    public double getTemperatura() {
        return temperaturaAtual;
    }
    
    public void setTemperatura(double novaTemperatura) {
        if (novaTemperatura < 0) {
            throw new IllegalArgumentException("Erro: Temperatura do motor não pode ser negativa!");
        }
        temperaturaAtual = novaTemperatura;
    }
    
    public double getTemperaturaIdeal() {
        return temperaturaIdeal;
    }
    
    public void setTemperaturaIdeal(double novaTemperaturaIdeal) {
        if (novaTemperaturaIdeal < 0) {
            throw new IllegalArgumentException("Erro: Temperatura do motor não pode ser negativa!");
        }
        temperaturaIdeal = novaTemperaturaIdeal;
    }
    
    
    
    @Override
    public void simularFalha() {
        LocalDate dataHoje = LocalDate.now();
        long mesesUso = ChronoUnit.MONTHS.between(ultimaVerificação, dataHoje);
        temperaturaAtual = temperaturaAtual + (mesesUso * aumentoMes);
        
        System.out.printf("Temperatura atual: %.1f°C%n " , temperaturaAtual);
        
        int mesesProblema = 0;
        for (int i = 0; i <= mesesUso; i++) {
            double temp = temperaturaIdeal + (i * aumentoMes);
            
            if (temp > (temperaturaIdeal + 10.0)) {
                mesesProblema = (int)(mesesUso - i);
                break;
            }
        }
        
        if (temperaturaAtual > temperaturaIdeal + 20.0) {
            System.out.println("Atenção! Motor: " + nome + ", superaquecido! Perigo!");
            Equipamento.registrarProblema();
            
            double novaVida = Math.max(vidaUtil - ((mesesProblema * reduçãoVidaUtil)/12), 0);
            
            System.out.println("Devido à demora de " + mesesProblema + " meses, o motor teve sua vida útil reduzida para: " + String.format("%.1f", (novaVida)) + "/" + vidaUtil + " anos");
        } else if (temperaturaAtual > temperaturaIdeal + 10.0) {
            System.out.println("Atenção! Temperatura do motor: " + nome + ", está elevada acima do normal!");
            Equipamento.registrarProblema();
            
            double novaVida = Math.max(vidaUtil - ((mesesProblema * reduçãoVidaUtil)/12), 0);
            
            System.out.println("Devido à demora de " + mesesProblema + " meses, o motor teve sua vida útil reduzida para: " + String.format("%.1f", (novaVida)) + "/" + vidaUtil + " anos");
        } else {
            System.out.println("Temperatura do motor: " + nome + ", dentro da temperatura normal!");
            
            System.out.println("A vida útil do motor continua seguindo a média!");
        }
    }
    
    
    @Override
    public void correção() {
        if (temperaturaAtual > temperaturaIdeal + 20.0) {
            System.out.println("Sugestão de correção para o motor: " + nome + ": Substituição imediata do motor.");
        } else if (temperaturaAtual > temperaturaIdeal + 10.0) {
            System.out.println("Sugestão de correção para o motor: " + nome + ": Resfriar o motor e deixá-lo desligado por um tempo.");
        } else {
            System.out.println("Sugestão de correção para o motor: " + nome + ": nenhuma, motor em boas condições.");
        }
    }
    
    
    @Override
    public void exibirInfo() {
        super.exibirInfo();
        System.out.println("Temperatura atual: " + temperaturaAtual);
    }
    
    
    @Override
    public void resetar() {
        this.vidaUtil = 5;
        this.temperaturaIdeal = 70;
        this.temperaturaAtual = temperaturaIdeal;
        this.ultimaVerificação = dataInstalação;
    }
    
    
    
    @Override
    public void simularFalha1(LocalDate dataSimulada) {
        long mesesUso = ChronoUnit.MONTHS.between(ultimaVerificação, dataSimulada);
        double temperaturaSimulada = temperaturaAtual + (mesesUso * aumentoMes);
        
        System.out.printf("Temperatura simulada: %.1f°C%n " , temperaturaSimulada);
        
        int mesesProblema = 0;
        for (int i = 0; i <= mesesUso; i++) {
            double temp = temperaturaIdeal + (i * aumentoMes);
            
            if (temp > (temperaturaIdeal + 10.0)) {
                mesesProblema = (int)(mesesUso - i);
                break;
            }
        }
        
        if (temperaturaSimulada > temperaturaIdeal + 20.0) {
            System.out.println("Atenção! Motor " + nome + " estará superaquecido! Perigo!");
            Equipamento.registrarProblema();
            
            double novaVida = Math.max(vidaUtil - ((mesesProblema * reduçãoVidaUtil)/12), 0);
            
            System.out.println("Devido à demora de " + mesesProblema + " meses, o motor teve sua vida útil reduzida para: " + String.format("%.1f", (novaVida)) + "/" + vidaUtil + " anos");
        } else if (temperaturaSimulada > temperaturaIdeal + 10.0) {
            System.out.println("Atenção! Temperatura do motor " + nome + " estará elevada acima do normal!");
            Equipamento.registrarProblema();
            
            double novaVida = Math.max(vidaUtil - ((mesesProblema * reduçãoVidaUtil)/12), 0);
            
            System.out.println("Devido à demora de " + mesesProblema + " meses, o motor terá sua vida útil reduzida para: " + String.format("%.1f", (novaVida)) + "/" + vidaUtil + " anos");
        } else {
            System.out.println("Temperatura do motor " + nome + " estará dentro da temperatura normal!");
            
            System.out.println("A vida útil do motor continuará seguindo a média!");
        } 
    }
}