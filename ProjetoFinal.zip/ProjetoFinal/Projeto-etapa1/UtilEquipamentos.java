import java.util.List;



public class UtilEquipamentos {
    public static void verificarTodosEquipamentos(List<Equipamento>lista) {
        if (lista == null || lista.isEmpty()) {
            System.out.println("Nenhum equipamento para verificar.");
            return;
        }
            
        System.out.println("======= VERIFICAÇÃO DE TODOS OS EQUIPAMENTOS =======\n");
        for (Equipamento eq : lista) {
            eq.verificarManutenção();
            System.out.println("--------------------------------------------\n");
        }
    }

    public static void simularTodosEquipamentos(List<Equipamento>lista, java.time.LocalDate dataSimulada) {
        if (lista == null || lista.isEmpty()) {
            System.out.println("Nenhum equipamento para verificar.");
            return;
        }
        
        System.out.println("======= SIMULAÇÃO DE TODOS OS EQUIPAMENTOS =======\n");
        for (Equipamento eq : lista) {
            eq.simularVerificação(dataSimulada);
            System.out.println("--------------------------------------------\n");
        }
    }
}