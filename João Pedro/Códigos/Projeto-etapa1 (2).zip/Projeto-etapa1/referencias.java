referência para uso de throw: https://youtu.be/YPHhoXeJMDU


referência para LocalDate: https://www.treinaweb.com.br/blog/dica-de-codigo-trabalhando-com-data-e-hora-no-java
referência para LocalDate: https://youtu.be/G2rChxrc1ug


referência para ChronoUnit: https://youtu.be/17_tFE6Xna8


referência para comandos ao longo do codigo: https://docs.oracle.com/javase/8/docs/api/java/time/LocalDate.html


referência para limitar valores positivos: https://codegym.cc/pt/groups/posts/pt.398.metodo-java-lang-math-max-