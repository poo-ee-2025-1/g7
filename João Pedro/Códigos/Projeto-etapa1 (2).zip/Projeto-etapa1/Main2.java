import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Main2 {
    public static void main(String[] args) {
        List<Equipamento> equipamentos = new ArrayList<>();

        try {
            // ============ CRIAÇÃO DOS EQUIPAMENTOS ============
            MotorElétrico motor = new MotorElétrico("Motor A", LocalDate.parse("2023-05-15"));
            Gerador gerador = new Gerador("Gerador B", LocalDate.parse("2022-12-01"));
            Transformador transformador = new Transformador("Transformador C", LocalDate.parse("2020-07-10"));
            PainelEletrico painel = new PainelEletrico("Painel D", LocalDate.parse("2021-01-01"));

            // ============ CONFIGURAÇÕES EXTRAS ============
            motor.setTemperatura(95.0);  // Temperatura mais alta que o ideal
            gerador.setHorasUsado(480.0); // Perto do limite
            transformador.setDesgasteTotal(65.0); // Desgaste já acumulado

            // ============ ADICIONANDO À LISTA ============
            equipamentos.add(motor);
            equipamentos.add(gerador);
            equipamentos.add(transformador);
            equipamentos.add(painel);

            // ============ VERIFICAÇÃO NORMAL DE TODOS ============
            UtilEquipamentos.verificarTodosEquipamentos(equipamentos);

            // ============ SIMULAÇÃO EM DATA FUTURA ============
            LocalDate dataSimulada = LocalDate.parse("2025-12-30");
            UtilEquipamentos.simularTodosEquipamentos(equipamentos, dataSimulada);

            // ============ EXIBINDO INFORMAÇÕES DE TODOS ============
            System.out.println("\n======= EXIBINDO TODAS AS INFORMAÇÕES =======\n");
            for (Equipamento e : equipamentos) {
                e.exibirInfo();
                System.out.println();
            }

            // ============ SUGESTÕES DE CORREÇÃO ============
            System.out.println("\n======= SUGESTÕES DE CORREÇÃO =======\n");
            for (Equipamento e : equipamentos) {
                e.correção();
                System.out.println();
            }

            // ============ RESETANDO OS EQUIPAMENTOS ============
            System.out.println("\n======= RESETANDO TODOS OS EQUIPAMENTOS =======\n");
            for (Equipamento e : equipamentos) {
                e.resetar();
                e.exibirInfo();
                System.out.println();
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}