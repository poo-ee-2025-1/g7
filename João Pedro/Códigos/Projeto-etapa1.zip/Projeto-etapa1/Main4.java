import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class Main4 {
    public static void main(String[] args){
        MotorElétrico m = new MotorElétrico("Motor 1", LocalDate.parse("2024-07-02"));
        
        System.out.println("=======Exibindo informações=======\n");
        m.exibirInfo();
        
        System.out.println("\n=======Verificando manutenção=======");
        m.verificarManutenção();
        
    }
}