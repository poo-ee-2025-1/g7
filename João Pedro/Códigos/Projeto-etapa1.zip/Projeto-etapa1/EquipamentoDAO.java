import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class EquipamentoDAO {
    
    private static final String URL = "jdbc:sqlite:equipamentos.db";

    static {
        try (Connection conn = DriverManager.getConnection(URL);
             Statement stmt = conn.createStatement()) {

            String sql = "CREATE TABLE IF NOT EXISTS equipamentos (" +
                    "id TEXT PRIMARY KEY, " +
                    "tipo TEXT NOT NULL, " +
                    "nome TEXT NOT NULL, " +
                    "dataInstalacao TEXT NOT NULL, " +
                    "vidaUtil INTEGER, " +
                    "ultimaVerificacao TEXT, " +
                    "frequenciaManutencao INTEGER" +
                    ")";
            stmt.execute(sql);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void salvarEquipamento(Equipamento e) {
        String sql = "INSERT OR REPLACE INTO equipamentos (id, tipo, nome, dataInstalacao, vidaUtil, ultimaVerificacao, frequenciaManutencao) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = DriverManager.getConnection(URL);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, e.getID());
            pstmt.setString(2, e.tipo);
            pstmt.setString(3, e.nome);
            pstmt.setString(4, e.dataInstalação.toString());
            pstmt.setInt(5, e.vidaUtil);
            pstmt.setString(6, e.ultimaVerificação.toString());
            pstmt.setInt(7, e.frequenciaManutenções);

            pstmt.executeUpdate();

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    public static void atualizarEquipamento(Equipamento e) {
        salvarEquipamento(e); 
    }

    public static List<Equipamento> listarEquipamentos() {
        List<Equipamento> lista = new ArrayList<>();
        String sql = "SELECT * FROM equipamentos ORDER BY dataInstalacao";

        try (Connection conn = DriverManager.getConnection(URL);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                String tipo = rs.getString("tipo");
                String nome = rs.getString("nome");
                LocalDate dataInstalacao = LocalDate.parse(rs.getString("dataInstalacao"));
                int vidaUtil = rs.getInt("vidaUtil");
                LocalDate ultimaVerificacao = LocalDate.parse(rs.getString("ultimaVerificacao"));
                int freq = rs.getInt("frequenciaManutencao");

                Equipamento e = null;

                switch (tipo) {
                    case "Motor Elétrico":
                        e = new MotorElétrico(nome, dataInstalacao);
                        break;
                    case "Gerador":
                        e = new Gerador(nome, dataInstalacao);
                        break;
                    case "Transformador":
                        e = new Transformador(nome, dataInstalacao);
                        break;
                    case "Painel Elétrico":
                        e = new PainelEletrico(nome, dataInstalacao);
                        break;
                }

                if (e != null) {
                    e.vidaUtil = vidaUtil;
                    e.ultimaVerificação = ultimaVerificacao;
                    e.frequenciaManutenções = freq;
                    lista.add(e);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return lista;
    }
    
    public static void inicializarContadorID() {
        String sql = "SELECT MAX(CAST(id AS INTEGER)) as max_id FROM equipamentos";

        try (Connection conn = DriverManager.getConnection(URL);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            if (rs.next()) {
                int maxID = rs.getInt("max_id");
                Equipamento.setContaID(maxID);
                System.out.println("Contador de ID iniciado a partir do banco de dados: " + maxID);
            }
        } catch (SQLException e) {
            System.out.println("Erro ao inicializar contador de ID:");
            e.printStackTrace();
        }
    }
    
    public static void apagarTodosEquipamentos() {
        String sql = "DELETE FROM equipamentos";

        try (Connection conn = DriverManager.getConnection(URL);
             Statement stmt = conn.createStatement()) {
            stmt.executeUpdate(sql);
            System.out.println("Todos os equipamentos foram apagados do banco de dados.");
        } catch (SQLException e) {
            System.out.println("Erro ao apagar dados:");
            e.printStackTrace();
        }
    }
}