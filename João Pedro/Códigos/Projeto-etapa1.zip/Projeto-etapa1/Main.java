import java.util.List;
import java.time.LocalDate;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {

        System.out.println("====== TESTE 1: FALHAS PROPOSITADAS ======");
        ArrayList<Equipamento> falhas = new ArrayList<>();

        // Motor Elétrico com muitos meses sem verificação
        MotorElétrico motorFalha = new MotorElétrico("Motor B", LocalDate.of(2020, 1, 1));
        motorFalha.setTemperatura(150);  // Forçando temperatura extrema
        falhas.add(motorFalha);

        // Gerador com horas absurdamente altas
        Gerador geradorFalha = new Gerador("Gerador B", LocalDate.of(2021, 1, 1));
        geradorFalha.setHorasUsado(3306);  // Muito acima das 500h
        falhas.add(geradorFalha);

        // Transformador com desgaste muito alto
        Transformador transFalha = new Transformador("Transformador B", LocalDate.of(2021, 1, 1));
        transFalha.setDesgasteTotal(150);  // Acima de 100%
        falhas.add(transFalha);

        // Painel com muito tempo sem verificação (poeira acumulada)
        PainelEletrico painelFalha = new PainelEletrico("Painel B", LocalDate.of(2022, 1, 1));
        falhas.add(painelFalha);

        for (Equipamento e : falhas) {
            System.out.println("\n---- Verificando: " + e.getClass().getSimpleName() + " ----");
            e.verificarManutenção();
            e.correção();
        }


        System.out.println("\n\n====== TESTE 2: FUNCIONAMENTO NORMAL ======");
        ArrayList<Equipamento> normal = new ArrayList<>();

        MotorElétrico motor = new MotorElétrico("Motor A", LocalDate.of(2024, 6, 1));
        normal.add(motor);

        Gerador gerador = new Gerador("Gerador A", LocalDate.of(2024, 6, 1));
        normal.add(gerador);

        Transformador trans = new Transformador("Transformador A", LocalDate.of(2024, 6, 1));
        normal.add(trans);

        PainelEletrico painel = new PainelEletrico("Painel A", LocalDate.of(2024, 6, 1));
        normal.add(painel);

        for (Equipamento e : normal) {
            System.out.println("\n---- Verificando: " + e.getClass().getSimpleName() + " ----");
            e.verificarManutenção();
            e.correção();
            e.exibirInfo();
        }

        System.out.println("\nTOTAL DE PROBLEMAS IDENTIFICADOS: " + Equipamento.getTotalProblemas());
    }
}