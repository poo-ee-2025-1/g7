import java.time.LocalDate;
import java.util.List;

public class TesteBancoCompleto {
    public static void main(String[] args) {
        // Inicializa o contador de ID com base no maior valor salvo no banco
        EquipamentoDAO.inicializarContadorID();

        // Criação de novos equipamentos (como se o usuário estivesse cadastrando)
        Gerador g1 = new Gerador("Gerador Principal", LocalDate.of(2023, 3, 15));
        MotorElétrico m1 = new MotorElétrico("Motor da Fábrica", LocalDate.of(2022, 6, 10));
        Transformador t1 = new Transformador("Transformador Norte", LocalDate.of(2021, 1, 1));
        PainelEletrico p1 = new PainelEletrico("Painel da Entrada", LocalDate.of(2024, 2, 20));

        // Salva todos no banco
        EquipamentoDAO.salvarEquipamento(g1);
        EquipamentoDAO.salvarEquipamento(m1);
        EquipamentoDAO.salvarEquipamento(t1);
        EquipamentoDAO.salvarEquipamento(p1);

        // Lista todos os equipamentos salvos no banco
        System.out.println("\n=========== EQUIPAMENTOS SALVOS NO BANCO ===========");
        List<Equipamento> equipamentos = EquipamentoDAO.listarEquipamentos();
        for (Equipamento eq : equipamentos) {
            eq.exibirInfo();
            System.out.println("--------------------------------------------------");
        }

        // Simula uma verificação de manutenção em todos os equipamentos
        System.out.println("\n=========== VERIFICAÇÃO DE MANUTENÇÃO ===========");
        for (Equipamento eq : equipamentos) {
            eq.verificarManutenção();
            EquipamentoDAO.atualizarEquipamento(eq); // Salva a atualização no banco
            System.out.println("--------------------------------------------------");
        }
        
 
        //EquipamentoDAO.apagarTodosEquipamentos();
    }
}
