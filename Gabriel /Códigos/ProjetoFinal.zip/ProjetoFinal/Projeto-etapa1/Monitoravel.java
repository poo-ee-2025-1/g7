import java.time.LocalDate;
import java.time.temporal.ChronoUnit;


public interface Monitoravel {
    public void simularFalha();
    
    public void correção();
    
    public void exibirInfo();
    
    public void resetar();
    
    public void simularFalha1(LocalDate dataSimulada);
}