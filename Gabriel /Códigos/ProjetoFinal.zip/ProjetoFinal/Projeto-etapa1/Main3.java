import java.time.LocalDate;
import java.time.format.DateTimeParseException;

public class Main3 {
    public static void main(String[] args) {
        System.out.println("=== Teste 1: Data futura ===");
        try {
            LocalDate dataFutura = LocalDate.now().plusDays(10);
            MotorElétrico m1 = new MotorElétrico("Motor Futuro", dataFutura);
        } catch (IllegalArgumentException e) {
            System.out.println(e.getMessage());
        }

        System.out.println("\n=== Teste 2: Data em formato inválido ===");
        try {
            LocalDate dataInvalida = LocalDate.parse("12/06/2024"); // formato errado
            Gerador g1 = new Gerador("Gerador Formato Inválido", dataInvalida);
        } catch (DateTimeParseException e) {
            System.out.println("Erro: Formato de data inválido. Use o formato correto (AAAA-MM-DD).");
        }

        System.out.println("\n=== Teste 3: Nome em branco ===");
        try {
            LocalDate data = LocalDate.parse("2024-06-12");
            Transformador t1 = new Transformador("", data);
        } catch (IllegalArgumentException e) {
            System.out.println(e.getMessage());
        }

        System.out.println("\n=== Teste 4: Data de instalação nula ===");
        try {
            PainelEletrico p1 = new PainelEletrico("Painel Nulo", null);
        } catch (IllegalArgumentException e) {
            System.out.println(e.getMessage());
        }

        System.out.println("\n=== Teste 5: Valores negativos nos atributos ===");
        try {
            LocalDate data = LocalDate.parse("2024-06-10");
            Gerador g2 = new Gerador("Gerador Negativo", data);
            g2.setHorasUsado(-5); // inválido
        } catch (IllegalArgumentException e) {
            System.out.println(e.getMessage());
        }

        try {
            LocalDate data = LocalDate.parse("2024-06-10");
            MotorElétrico m2 = new MotorElétrico("Motor Negativo", data);
            m2.setTemperatura(-10); // inválido
        } catch (IllegalArgumentException e) {
            System.out.println(e.getMessage());
        }

        try {
            LocalDate data = LocalDate.parse("2024-06-10");
            Transformador t2 = new Transformador("Transformador Negativo", data);
            t2.setDesgasteTotal(-3); // inválido
        } catch (IllegalArgumentException e) {
            System.out.println(e.getMessage());
        }
    }
}